<section class="col-lg-7 connectedSortable">
    <?php include "home_welcome.php"; ?>
</section><!-- /.Left col -->

<section class="col-lg-5 connectedSortable">
    <?php include "home_quick_email.php"; ?>
</section><!-- right col -->

<div style='clear:both'></div>