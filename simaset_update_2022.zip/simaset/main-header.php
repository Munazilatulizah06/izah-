<style type="text/css">
  .sekolah{
    float: left;
    background-color: transparent;
    background-image: none;
    padding: 15px 15px;
    font-family: fontAwesome;
    color:#fff;
  }

  .sekolah:hover{
    color:#fff;
  }
</style>
        <!-- Logo -->
        <a href="index.php" style='background-color:#025c00' class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini">SA</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>SIM ASSET</b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav style='background-color:#222d32' class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>

          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <li><a href="?open=Logout" >Logout</a></li>
            </ul>
          </div>
        </nav>