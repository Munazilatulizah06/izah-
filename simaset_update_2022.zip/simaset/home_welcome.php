              <div class="box box-info">
                <div class="box-header">
                  <h3 class="box-title">Selamat Data Di Sistem Informasi Manajemen Aset</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <div class="box-body">
                  <p>Sistem Informasi Manajemen Aset (SIMA) (SIM ASET) merupakan sistem informasi manajemen pendataan aset (inventaris dan ruang) secara terintegrasi seluruh instansi dalam rangka melaksanakan tertib administrasi pengelolaan dan pendataan barang. Aturan yang kami jadikan acuan dalam perancangan SIM Aset ini, salah satunya adalah Permendagri No. 17 Tahun 2007. Sistem ini dapat digunakan baik di lingkungan Pemerintah Daerah maupun Perguruan Tinggi.</p>
                  <p>Sistem Informasi Aset berfungsi untuk melakukan pencatatan mengenai pengadaan, pengesahan, penggunaan, perawatan, status, serta kondisi aset tersebut. 
                    Aset dapat meliputi inventarisasi tanah, inventarisasi gedung, inventarisasi alat angkutan, inventarisasi senjata api, inventarisasi jaringan, inventarisasi peralatan seperti alat tulis kantor & alat laboratorium, inventarisasi ruang/gudang dan barang-barang yang terdapat di dalamnya, inventarisasi lokasi lainnya dan barang-barang yang terdapat di dalamnya.</p>
                  <p>Sistem ini dapat digunakan oleh <b>Biro Sarana Prasarana (BSP), Biro Administrasi Umum (BAU), Bagian Gudang, Bagian Rumah Tangga, Bagian Kendaraan, </b>hingga <b>Seksi Keamanan</b>.<br>
                    Aset-aset yang dimiliki oleh suatu Instansi dapat dipantau tentang<b> keberadaan, nilai, perpindahan dan kondisinya</b>. Sistem Informasi Aset dipersiapkan untuk Kebutuhan Perencanaan dalam Utilisasi Ruang dan sharing Fasilitas antar Departemen atau Pihak tertentu.</p>
                  <p><b>Sistem Informasi Manajemen Aset</b> ini dirancang dengan platform Web Based (<b>berbasis Web</b>) dan telah support <b>Barcode Reader</b>. Sistem ini dapat diaplikasikan dalam Intranet maupun Online Internet. SIM Aset dikembangkan mengikuti alur business process, mulai dari pengadaan barang hingga distribusi barang. Barang tersebut akan tercatat sebagai Barang Aset dan terdata pada sebuah Ruang. Aset yang tercatat dalam software ini meliputi Gedung, Ruang beserta segala macam barang yang berada di dalamnya.</p>
              </div>
