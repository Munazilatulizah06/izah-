<ul>
	<li><a href="?open=Laporan-Petugas">Laporan Data Petugas</a></li>
	<li><a href="?open=Laporan-Supplier">Laporan Data Supplier</a></li>
	<li><a href="?open=Laporan-Pegawai">Laporan Data Pegawai</a></li>
	<li><a href="?open=Laporan-Departemen">Laporan Data Departemen</a></li>
	<li><a href="?open=Laporan-Lokasi">Laporan Data Lokasi</a></li>
	<li><a href="?open=Laporan-Kategori">Laporan Data Kategori</a></li>
	<li><a href="?open=Laporan-Barang">Laporan Data Barang</a></li>
	<li><a href="?open=Laporan-Barang-Kategori">Laporan Barang per Kategori</a></li>
	<li><a href="?open=Laporan-Barang-Lokasi">Laporan Barang per Lokasi</a></li>
	
	<li><a href="?open=Laporan-Pengadaan-Periode">Laporan Pengadaan per Periode</a></li>
	<li><a href="?open=Laporan-Pengadaan-Bulan">Laporan Pengadaan per Bulan</a></li>
	<li><a href="?open=Laporan-Pengadaan-Supplier">Laporan Pengadaan per Supplier</a></li>

	<li><a href="?open=Laporan-Pengadaan-Barang-Periode">Laporan Pengadaan Barang Per Periode </a></li>
	<li><a href="?open=Laporan-Pengadaan-Barang-Bulan">Laporan Pengadaan Barang Per Bulan </a></li>
    <li><a href="?open=Laporan-Pengadaan-Barang-Kategori">Laporan Pengadaan Barang Per Kategori</a></li>
    <li><a href="?open=Laporan-Pengadaan-Barang-Supplier">Laporan Pengadaan Barang  Per Supplier </a></li>

	<li><a href="?open=Laporan-Penempatan-Periode">Laporan Penempatan per Periode</a></li>
	<li><a href="?open=Laporan-Penempatan-Bulan">Laporan Penempatan per Bulan</a></li>
	<li><a href="?open=Laporan-Penempatan-Lokasi">Laporan Penempatan per Lokasi</a></li>
	
	<li><a href="?open=Laporan-Mutasi-Periode">Laporan Mutasi per Periode</a></li>
	<li><a href="?open=Laporan-Mutasi-Bulan">Laporan Mutasi per Bulan</a></li>
    <li><a href="?open=Laporan-Mutasi-Barang-Lokasi">Laporan Mutasi Barang - Per Lokasi </a></li>

	<li><a href="?open=Laporan-Peminjaman-Periode">Laporan Peminjaman per Periode</a></li>
	<li><a href="?open=Laporan-Peminjaman-Bulan">Laporan Peminjaman per Bulan</a></li>
	<li><a href="?open=Laporan-Peminjaman-Pegawai">Laporan Peminjaman per Pegawai</a></li>
</ul>
