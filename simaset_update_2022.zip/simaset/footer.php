<div class="pull-right hidden-xs">
    <b></b>
</div>
<strong>Copyright &copy; <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com">- SIMASET (Sistem Informasi Manajemen Aset)</a>.</strong> All rights reserved.