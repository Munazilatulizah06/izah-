<?php
# PILIHAN SATUAN PRODUK / BARANG
$satuan	= array();
$satuan[] = "Unit";
$satuan[] = "Botol";
$satuan[] = "Dos";
$satuan[] = "Karton";
$satuan[] = "Lembar";
$satuan[] = "Meter";
$satuan[] = "Buah";

# PILIHAN JENIS PENGADAAN
$jenisPengadaan	= array();
$jenisPengadaan[] = "Pembelian";
$jenisPengadaan[] = "Sumbangan";
$jenisPengadaan[] = "Wakaf";
$jenisPengadaan[] = "Hibah"; 
$jenisPengadaan[] = "Hadiah";
$jenisPengadaan[] = "Donasi";
?>